#!/usr/bin/env python
# Validate a DIMACS CNF against a DIMACS-style model file.
# Usage: python validate_dimacs_model.py --cnf PATH --model PATH

import argparse

def parse_cnf(path: str):
    nvars = nclauses = None
    clauses = []
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('c'):
                continue
            if line.startswith('p'):
                _, fmt, nv, nc = line.split()[:4]
                if fmt.lower() != 'cnf':
                    raise ValueError(f'Unsupported format: {fmt}')
                nvars, nclauses = int(nv), int(nc)
                continue
            parts = line.split()
            lits = [int(x) for x in parts]
            if lits and lits[-1] == 0:
                lits = lits[:-1]
            if lits:
                clauses.append(lits)
    return nvars, nclauses, clauses


def parse_model(path: str, nvars: int):
    assign = [None] * (nvars + 1)
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('c') or line.startswith('s'):
                continue
            if line.startswith('v'):
                parts = line.split()[1:]
            else:
                parts = line.split()
            for tok in parts:
                lit = int(tok)
                if lit == 0:
                    continue
                v = abs(lit)
                if v <= nvars:
                    assign[v] = (lit > 0)
    # default unspecified variables to False
    for v in range(1, nvars + 1):
        if assign[v] is None:
            assign[v] = False
    return assign


def clause_sat(clause, assign):
    for lit in clause:
        v = abs(lit)
        val = assign[v]
        if (lit > 0 and val) or (lit < 0 and not val):
            return True
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--cnf', required=True)
    ap.add_argument('--model', required=True)
    ap.add_argument('--list-unsat', action='store_true')
    ap.add_argument('--max-list', type=int, default=50)
    args = ap.parse_args()

    nvars, nclauses, clauses = parse_cnf(args.cnf)
    assign = parse_model(args.model, nvars)

    unsat_idx = []
    for i,cl in enumerate(clauses):
        if not clause_sat(cl, assign):
            unsat_idx.append(i)

    print(f'nvars={nvars}  clauses_read={len(clauses)}  header_clauses={nclauses}')
    print(f'UNSAT={len(unsat_idx)}')
    if args.list_unsat and unsat_idx:
        print('First UNSAT clause indices:')
        for i in unsat_idx[:args.max_list]:
            print(i)


if __name__ == '__main__':
    main()
