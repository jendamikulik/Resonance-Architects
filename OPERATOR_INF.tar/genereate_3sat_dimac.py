import random

def generate_huge_cnf(filename, n_vars, ratio=4.26):
    n_clauses = int(n_vars * ratio)
    print(f"Generuji {n_vars} proměnných a {n_clauses} klauzulí do {filename}...")

    with open(filename, 'w') as f:
        f.write(f"p cnf {n_vars} {n_clauses}\n")
        for _ in range(n_clauses):
            # Náhodný výběr 3 unikátních proměnných
            vars_sample = random.sample(range(1, n_vars + 1), 3)
            # Náhodná polarita (True/False)
            clause = [v if random.random() > 0.5 else -v for v in vars_sample]
            f.write(f"{clause[0]} {clause[1]} {clause[2]} 0\n")


if __name__ == "__main__":
    # 10 milionů proměnných, poměr 4.26 (hard region)
    generate_huge_cnf("thin_red_line.cnf", 3000002)
    print("Hotovo.")

